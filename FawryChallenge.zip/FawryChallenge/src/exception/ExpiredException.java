package exception;

public class ExpiredException extends Exception {
	public ExpiredException() {
        super();
    }
	
    public ExpiredException(String message) {
        super(message);
    }
}
