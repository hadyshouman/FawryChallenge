package exception;

public class InsuffecientBalanceException extends Exception {
	public InsuffecientBalanceException() {
        super();
    }
	
    public InsuffecientBalanceException(String message) {
        super(message);
    }

}
