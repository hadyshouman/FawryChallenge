package shop;

public interface expirable {
	public boolean isExpired();
}
