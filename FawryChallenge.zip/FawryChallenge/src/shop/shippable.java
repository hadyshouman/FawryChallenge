package shop;

public interface shippable {
	public String getName();
	public double getWeight();
}
