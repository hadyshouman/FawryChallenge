package shop;

import java.time.LocalDate;

public class Product implements shippable, expirable {
	private String name;
	private double price;
	private int quantity;
	private double weight; 
	private boolean shippable; // false if product isn't shippable
	private LocalDate expiryDate; //null if product isn't expirable

	public Product(String name, double price, int quantity,
			double weight, boolean shippable, LocalDate expiryDate) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.weight = weight;
		this.shippable = shippable;
		this.expiryDate=expiryDate;
	}
	


	//needed methods
	public boolean isExpired(){
		return !(expiryDate==null) && (LocalDate.now().isAfter(expiryDate)); // false if product doesn't expire
																			//or expiry date has passed
	}
	
	public void remove(int amount){ //when a product is bought or added to cart
		this.quantity-=amount;
	}
	public void increase(int amount){
		this.quantity+=amount;
	}
	//getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public boolean isShippable() {
		return shippable;
	}

	public void setShippable(boolean shippable) {
		this.shippable = shippable;
	}
	
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	
}
