package shop;


public class Customer {
	private double balance;
	
	public Customer (double balance){
		this.balance=balance;
	}
	
	public void decreaseBalanceBy(double amount){
		this.balance-=amount;
	}

	public double getBalance() {
		return balance;
	}
	
}
