package shop;

import java.util.ArrayList;

public class ShippingService {
	private final int shippingFee=30; // Assume shipping fee is constant
	private ArrayList<shippable> shippableItems;
	
	public ShippingService() {
		this.shippableItems = null;
	}
	
	
	public ShippingService(ArrayList<shippable> shippableItems) {
		this.shippableItems = shippableItems;
	}


	public void add(Product p){
		shippableItems.add(p);
	}
	public int getShippingFee() {
		return shippingFee;
	}
	
	
	public ArrayList<shippable> getShippableItems() {
		return shippableItems;
	}
	
	

}
