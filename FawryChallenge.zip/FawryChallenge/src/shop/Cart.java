package shop;

import java.util.*;

import exception.*;
public class Cart {
	private ArrayList<CartItem> cart;
	private double priceSoFar;
	public Cart(){
		this.priceSoFar=0;
		this.cart=new ArrayList<>();
	}
	
	public void add(Product p,int quantity) throws OutOfStockException,ExpiredException{
		if(p.getQuantity()<=quantity)
			throw new OutOfStockException( p+ " is out of stock");
		if(p.getExpiryDate()!=null)
			if(p.isExpired())
				throw new ExpiredException( p+ " is Expired");
		
		priceSoFar+=(p.getPrice())*quantity;
		CartItem item= new CartItem(p,quantity);
		cart.add(item);
		p.remove(quantity);
	}
	
	public void remove(CartItem item) {
	    for (int i = 0; i < cart.size(); i++) {
	    	CartItem current=cart.get(i);
	        if (current.getProduct().equals(item.getProduct())) {
	        	priceSoFar-=(current.getProduct().getPrice())*(current.getQuantity()); //update priceSoFar
	        	current.getProduct().increase(current.getQuantity()); // update product's stock 
	            cart.remove(i);										 //as more is available now
	            break; 
	        }
	    }
	    
	    
	}
	
	public void shipmentPrint(){
		System.out.println("** Shipment notice **");
		double overallWeight=0;
		for(CartItem current: cart){
			if(current.getProduct().isShippable()){
				double productWeight=current.getProduct().getWeight() * current.getQuantity();
				overallWeight+=productWeight;
				System.out.println(current.getQuantity()+ "x "+ current.getProduct().getName()+
						"		" + productWeight + "g"  );
			}
		}
		overallWeight/=1000;
		System.out.println("Total package weight is " + overallWeight+"kg \n\n");
	}

	public void checkoutPrint(){
		System.out.println("** Checkout receipt **");
		for(CartItem current: cart){
			System.out.println(current.getQuantity()+ "x "+ current.getProduct().getName()+
						"			"+ current.getProduct().getPrice()*current.getQuantity());
		}
		ShippingService s=new ShippingService();
		System.out.println("\n ---------------------- \n");
		System.out.println("SubTotal	"+ priceSoFar);
		System.out.println("Shipping	"+ s.getShippingFee());
		System.out.println("Amount		"+ (priceSoFar+s.getShippingFee()));
		
	}
	
	public ArrayList<shippable>  collectShippableItems(){
		ArrayList<shippable> shippableItems=new ArrayList<>();
		for(CartItem current: cart){
			if(current.getProduct().isShippable())
				shippableItems.add(current.getProduct());
		}
		return shippableItems;
	}
	
	public double getPriceSoFar() {
		return priceSoFar;
	}

	public ArrayList<CartItem> getCart() {
		return cart;
	}
	

}
