package shop;

import java.time.LocalDate;

import exception.*;

public class Console {
	public static void checkout(Customer customer,Cart cart) throws EmptyCartException, InsuffecientBalanceException{
		if(cart.getCart()==null)
			throw new EmptyCartException("Cart is Empty");
		if (cart.getPriceSoFar() > customer.getBalance())
			throw new InsuffecientBalanceException("Insuffecient Balance");
		System.out.println("Customer's Balance: "+ customer.getBalance()+"\n");
		cart.shipmentPrint();
		cart.checkoutPrint();
		customer.decreaseBalanceBy(cart.getPriceSoFar());
		System.out.println("Customer's remaining balance: "+ customer.getBalance());
	}
	
	public static void main(String[] args){
		Product cheese=new Product("Cheese",100,10,200,true,LocalDate.of(2025,7,10));
		Product biscuits=new Product("Biscuits",700,15,150,true,LocalDate.of(2025, 7, 20));
		Product tv=new Product("TV",10000,3,15000,true,null);
		Product scratchCards=new Product("ScratchCards",10,100,20,false,null);
		
		Customer customer= new Customer(200000);
		Cart cart=new Cart();
		
		try{
			cart.add(cheese, 2);
			cart.add(biscuits, 1);
			cart.add(tv, 1);
			cart.add(scratchCards,5);
			checkout(customer,cart);
			ShippingService shippingService=new ShippingService(cart.collectShippableItems());
		}
		catch (OutOfStockException | ExpiredException e) {
            System.out.println("Could not add product to cart: " + e.getMessage());
        }
        catch (EmptyCartException | InsuffecientBalanceException e) {
            System.out.println("Checkout failed: " + e.getMessage());
        }
		
	}
}